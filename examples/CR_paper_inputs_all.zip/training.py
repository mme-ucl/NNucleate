#!/bin/python3

import matplotlib.pyplot as plt
import torch
import numpy as np
from torch.utils.data import Dataset, DataLoader
from torch import nn
from torch import optim
from NNucleate.dataset import GNNTrajectory_mult
from NNucleate.models import initialise_weights, GNNCV_mult, GNNCV
from NNucleate.training import evaluate_model_gnn_mult, train_gnn_mult
from NNucleate.pycv_link import write_fast_link
from NNucleate.utils import get_rc_edges
import random
import mdtraj as md
import math
from ase.calculators.eam import EAM
import ase 

from scipy.interpolate import InterpolatedUnivariateSpline as spline
class EAM_ase:
    def __init__(self, **kwargs):
        self.read_potential(kwargs['potential'])

    def read_potential(self, filename):
        """Reads a LAMMPS EAM file in alloy or adp format
        and creates the interpolation functions from the data
        """
        if isinstance(filename, str):
            with open(filename) as fd:
                self._read_potential(fd)
        else:
            fd = filename
            self._read_potential(fd)

    def _read_potential(self, fd):

        lines = fd.readlines()
        def lines_to_list(lines):
            """Make the data one long line so as not to care how its formatted
            """
            data = []
            for line in lines:
                data.extend(line.split())
            return data
        self.header = lines[:1]
        data = lines_to_list(lines[1:])
        # eam form is just like an alloy form for one element
        self.Nelements = 1
        self.Z = np.array([data[0]], dtype=int)
        self.mass = np.array([data[1]])
        self.a = np.array([data[2]])
        self.lattice = [data[3]]
        self.nrho = int(data[4])
        self.drho = float(data[5])
        self.nr = int(data[6])
        self.dr = float(data[7])
        self.cutoff = float(data[8])
        n = 9 + self.nrho
        self.embedded_data = np.array([np.float64(data[9:n])])
        self.rphi_data = np.zeros([self.Nelements, self.Nelements,
                                      self.nr])
        effective_charge = np.float64(data[n:n + self.nr])
        # convert effective charges to rphi according to
        # http://lammps.sandia.gov/doc/pair_eam.html
        self.rphi_data[0, 0] = ase.units.Bohr * ase.units.Hartree * (effective_charge**2)
        self.density_data = np.array(
               [np.float64(data[n + self.nr:n + 2 * self.nr])])
        self.r = np.arange(0, self.nr) * self.dr
        self.rho = np.arange(0, self.nrho) * self.drho
        # choose the set_splines method according to the type
        self.set_splines()
    def set_splines(self):
        # this section turns the file data into three functions (and
        # derivative functions) that define the potential
        self.embedded_energy = np.empty(self.Nelements, object)
        self.electron_density = np.empty(self.Nelements, object)
        for i in range(self.Nelements):
            self.embedded_energy[i] = spline(self.rho,
                                             self.embedded_data[i], k=3)
            self.electron_density[i] = spline(self.r,
                                              self.density_data[i], k=3)
        self.phi = np.empty([self.Nelements, self.Nelements], object)
        # ignore the first point of the phi data because it is forced
        # to go through zero due to the r*phi format in alloy and adp
        for i in range(self.Nelements):
            for j in range(i, self.Nelements):
                self.phi[i, j] = spline(
                    self.r[1:],
                    self.rphi_data[i, j][1:] / self.r[1:], k=3)
                
    def calculate(self, config, edges, box_l):
        row, col = edges
        # All the distances
        drs = config[row] - config[col]
        inv_box = 1.0 / box_l
        dr = drs - box_l * torch.round(drs * inv_box)

        rs = torch.norm(dr, dim=1)
        # Look up rhos
        rho = torch.Tensor(self.electron_density[0](rs.detach().cpu().numpy())).to(device)
        #print(torch.max(rs))
        # Look up phis
        phi = torch.Tensor(self.phi[0, 0](rs.detach().cpu().numpy())).to(device)

        rhos_pa = torch.zeros(config.size(0), dtype=torch.float32).to(device).scatter_add(0, row, rho)
        phis_pa = torch.zeros(config.size(0), dtype=torch.float32).to(device).scatter_add(0, row, phi)
        # Calculate the energy
        Eis = torch.tensor(self.embedded_energy[0](rhos_pa.detach().cpu().numpy())).to(device) + 0.5*phis_pa

        E = torch.zeros(int(config.size(0)/500), dtype=torch.float64).to(device).scatter_add(0,torch.tensor(np.repeat(np.arange(int(config.size(0)/500)), 500)).to(device), Eis)
        return E



calc = EAM_ase(potential="../../Cu_u3.eam")

def e_path_loss(model, config, edges, edges_e, n_nodes, box, batch_size, beta, alpha=0.9, emax=10, L=5):
    err = torch.zeros(batch_size).to(device)
    pred = model(x=config, edges=edges, n_nodes=n_nodes)
    epots = calc.calculate(config*10, edges_e, box*10)
    #gs0 = torch.autograd.grad(pred[:,0], config, grad_outputs=torch.ones_like(pred[:,0]), retain_graph=True)[0]
    gs = torch.autograd.grad(pred[:,1], config, grad_outputs=torch.ones_like(pred[:,1]), retain_graph=True)[0]
    #gs = gs0 + gs1
    #gs = torch.autograd.grad(pred, config, grad_outputs=torch.ones_like(pred), retain_graph=True)[0].to(device)
    gs = gs/np.max(gs.detach().cpu().numpy())*0.1

    for i in range(1,L):
        # move in the direction of the grads (- for larger pred towards 1)
        config = config + gs*1
        # reevaluate the prediction
        pred_new = model(x=config, edges=edges, n_nodes=n_nodes)
        # reevaluate the energies
        epots_new = calc.calculate(config*10, edges_e, box*10)
        delta_pred = torch.abs(torch.norm(pred_new, p=1) - torch.norm(pred, p=1))
        delta_epot = torch.abs(epots_new - epots)
        # Add the new error decayed by distance mapped between 0 and 1 and then scaled to emax
        err += alpha**(i) * torch.minimum(torch.abs(torch.log(delta_pred)-beta*delta_epot), torch.tensor(emax))
        epots = epots_new
        pred = pred_new
        #gs0 = torch.autograd.grad(pred[:,0], config, grad_outputs=torch.ones_like(pred[:,0]), retain_graph=True)[0]
        gs = torch.autograd.grad(pred[:,1], config, grad_outputs=torch.ones_like(pred[:,1]), retain_graph=True)[0]
        #gs = gs0 + gs1
        #gs = torch.autograd.grad(pred_new, config, grad_outputs=torch.ones_like(pred_new), retain_graph=True)[0].to(device)
        gs = gs/np.max(gs.detach().cpu().numpy())*0.1

    return err

def train_gnn_comm_reg(
    model,
    loader: DataLoader,
    n_mol: int,
    optimizer,
    loss,
    cols,
    device: str,
    kT: float,
    lamb=1,
    n_at=1,
    alpha=0.9,
    emax=10,
    L=5
) -> float:
    """Function to perform one epoch of a GNN training.

    :param model: Graph-based model_t to be trained.
    :type model: GNNCV
    :param loader: Wrapper around a GNNTrajectory dataset.
    :type loader: torch.utils.data.Dataloader
    :param n_at: Number of nodes per frame.
    :type n_at: int
    :param optimizer: The optimizer object for the training.
    :type optimizer: torch.optim
    :param loss: Loss function for the training.
    :type loss: torch.nn._Loss
    :param device: Device that the training is performed on. (Required for GPU compatibility)
    :type device: str
    :param n_at: Number of atoms per molecule.
    :type n_at: int, optional
    :return: Return the average loss over the epoch.
    :rtype: float
    """
    resi = {"loss": 0, "path_loss":0, "total_loss":0, "counter": 0}
    for batch, (X, y, r, c, re, ce) in enumerate(loader):
        model.train()
        optimizer.zero_grad()
        batch_size = len(X)
        X.requires_grad = True
        ap = X.view(-1, 3 * n_at).to(device)
        row_new = []
        col_new = []
        for i in range(0, len(r)):
            row_new.append(r[i][r[i] >= 0] + n_mol * (i))
            col_new.append(c[i][c[i] >= 0] + n_mol * (i))

        row_new = torch.cat([ro for ro in row_new])
        col_new = torch.cat([co for co in col_new])

        if row_new[0] >= n_mol - 1:
            row_new -= n_mol
            col_new -= n_mol

        edges = [row_new.long().to(device), col_new.long().to(device)]

        row_new_e = []
        col_new_e = []
        for i in range(0, len(r)):
            row_new_e.append(re[i][re[i] >= 0] + n_mol * (i))
            col_new_e.append(ce[i][ce[i] >= 0] + n_mol * (i))

        row_new_e = torch.cat([ro for ro in row_new_e])
        col_new_e = torch.cat([co for co in col_new_e])

        if row_new_e[0] >= n_mol - 1:
            row_new_e -= n_mol
            col_new_e -= n_mol

        edges_e = [row_new_e.long().to(device), col_new_e.long().to(device)]

        label = y[:,cols].to(device)
        beta = 1/(kT)
        pred = model(x=ap, edges=edges, n_nodes=n_mol)

        path_loss = torch.mean(e_path_loss(model, ap, edges, edges_e, n_mol, 1.8658222, batch_size, beta, alpha, emax, L))
        #print(path_loss)
        l = loss(pred, label)
        resi["loss"] += l.item() * batch_size
        resi["path_loss"] += torch.mean(path_loss).item() * batch_size

        #print(comm_reg)
        l += lamb*torch.mean(path_loss)

        l.backward()
        optimizer.step()

        resi["total_loss"] += l.item() * batch_size
        resi["counter"] += batch_size

    return resi["total_loss"] / resi["counter"], resi["loss"] / resi["counter"], resi["path_loss"] / resi["counter"]


def train_gnn_e(
    model,
    loader: DataLoader,
    n_mol: int,
    optimizer,
    loss,
    cols,
    device: str,
    n_at=1,
) -> float:
    """Function to perform one epoch of a GNN training.

    :param model: Graph-based model_t to be trained.
    :type model: GNNCV
    :param loader: Wrapper around a GNNTrajectory dataset.
    :type loader: torch.utils.data.Dataloader
    :param n_at: Number of nodes per frame.
    :type n_at: int
    :param optimizer: The optimizer object for the training.
    :type optimizer: torch.optim
    :param loss: Loss function for the training.
    :type loss: torch.nn._Loss
    :param device: Device that the training is performed on. (Required for GPU compatibility)
    :type device: str
    :param n_at: Number of atoms per molecule.
    :type n_at: int, optional
    :return: Return the average loss over the epoch.
    :rtype: float
    """
    resi = {"loss": 0, "counter": 0}
    for batch, (X, y, r, c, re, ce) in enumerate(loader):
        model.train()
        optimizer.zero_grad()
        batch_size = len(X)
        X.requires_grad = True
        ap = X.view(-1, 3 * n_at).to(device)
        row_new = []
        col_new = []
        for i in range(0, len(r)):
            row_new.append(r[i][r[i] >= 0] + n_mol * (i))
            col_new.append(c[i][c[i] >= 0] + n_mol * (i))

        row_new = torch.cat([ro for ro in row_new])
        col_new = torch.cat([co for co in col_new])

        if row_new[0] >= n_mol - 1:
            row_new -= n_mol
            col_new -= n_mol

        edges = [row_new.long().to(device), col_new.long().to(device)]
        label = y[:,cols].to(device)
        pred = model(x=ap, edges=edges, n_nodes=n_mol)
        #print(path_loss)
        l = loss(pred, label)
        l.backward()
        optimizer.step()

        resi["loss"] += l.item() * batch_size
        resi["counter"] += batch_size

    return  resi["loss"] / resi["counter"]


def test_gnn_e(
    model: GNNCV, loader: DataLoader, n_mol: int, loss_l1, cols, device: str, kT: float,
    lamb=1,
    n_at=1,
    alpha=0.9,
    emax=10,
    L=5

    ):
    """Evaluate the test/validation error of a graph based model_t on a validation set. 

    :param model: Graph-based model_t to be trained.
    :type model: GNNCV
    :param loader: Wrapper around a GNNTrajectory dataset.
    :type loader: torch.utils.data.Dataloader
    :param n_mol: Number of nodes per frame.
    :type n_mol: int
    :param loss_l1: Loss function for the training.
    :type loss_l1: torch.nn._Loss
    :param device: Device that the training is performed on. (Required for GPU compatibility)
    :type device: str
    :param n_at: Number of atoms per molecule.
    :type n_at: int, optional
    :return: Return the average loss over the epoch.
    :rtype: float
    """
    res = {"loss": 0, "counter": 0, "path_loss": 0}
    for batch, (X, y, r, c, re, ce) in enumerate(loader):
        model.eval()
        batch_size = len(X)

        X.requires_grad = True
        atom_positions = X.view(-1, 3 * n_at).to(device)

        row_new = []
        col_new = []
        for i in range(0, len(r)):
            row_new.append(r[i][r[i] >= 0] + n_mol * (i))
            col_new.append(c[i][c[i] >= 0] + n_mol * (i))

        row_new = torch.cat([ro for ro in row_new])
        col_new = torch.cat([co for co in col_new])
        if row_new[0] >= n_mol - 1:
            row_new -= n_mol
            col_new -= n_mol

        edges = [row_new.long().to(device), col_new.long().to(device)]
        
        row_new_e = []
        col_new_e = []
        for i in range(0, len(r)):
            row_new_e.append(re[i][re[i] >= 0] + n_mol * (i))
            col_new_e.append(ce[i][ce[i] >= 0] + n_mol * (i))

        row_new_e = torch.cat([ro for ro in row_new_e])
        col_new_e = torch.cat([co for co in col_new_e])

        if row_new_e[0] >= n_mol - 1:
            row_new_e -= n_mol
            col_new_e -= n_mol

        edges_e = [row_new_e.long().to(device), col_new_e.long().to(device)]

        label = y[:,cols].to(device)
        pred = model(x=atom_positions, edges=edges, n_nodes=n_mol)
        # print(label, pred)
        loss = loss_l1(pred, label)

        beta = 1/(kT)

        path_loss = torch.mean(e_path_loss(model, atom_positions, edges, edges_e, n_mol, 1.8658222, batch_size, beta, alpha, emax, L))
        res["loss"] += loss.item() * batch_size
        res["counter"] += batch_size
        res["path_loss"] += path_loss.item() * batch_size

    return res["loss"] / res["counter"], res["path_loss"] / res["counter"]




from NNucleate.utils import pbc
class GNNTrajectory_energy(Dataset):
    """Generates a dataset from a trajectory in .xtc/.xyz format for the training of a GNN.
    .. warning:: For .xtc give the boxlength in nm and for .xyz give the boxlength in Å.

    :param cv_file: Path to the cv file.
    :type cv_file: str
    :param traj_name: Path to the trajectory file (.xtc/.xyz).
    :type traj_name: str
    :param top_file: Path to the topology file (.pdb).
    :type top_file: str
    :param cv_col: Gives the colimn in which the CV of interest is stored.
    :type cv_col: int
    :param box_length: Length of the cubic box.
    :type box_length: float
    :param rc: Cut-off radius for the construction of the graph.
    :type rc: float
    :param start: Starting frame of the trajectory, defaults to 0.
    :type start: int, optional
    :param stop: The last file of the trajectory that is rea, defaults to -1.
    :type stop: int, optional
    :param stride: The stride with which the trajectory frames are read, defaults to 1.
    :type stride: int, optional
    :param root: Allows for the loading of the n-th root of the CV data (to compress the numerical range), defaults to 1.
    :type root: int, optional
    """

    def __init__(
        self,
        cv_file: str,
        traj_name: str,
        top_file: str,
        box_length: float,
        rc: float,
        rc_e: float,
        start=0,
        stop=-1,
        stride=1,
        root=1,
    ):

        self.cv_labels = np.loadtxt(cv_file)[start:stop:stride, :] ** (1 / root)
        self.length = box_length
        traj = pbc(md.load(traj_name, top=top_file), self.length)[start:stop:stride]
        vecs = np.zeros((len(traj), 3, 3))
        for i in range(len(traj)):
            vecs[i, 0] = np.array([self.length, 0, 0])
            vecs[i, 1] = np.array([0, self.length, 0])
            vecs[i, 2] = np.array([0, 0, self.length])
        traj.unitcell_vectors = vecs
        traj = pbc(traj, self.length)
        self.rows, self.cols = get_rc_edges(rc, traj)
        self.rows_e, self.cols_e = get_rc_edges(rc_e, traj) 
        self.max_l = np.max([len(r) for r in self.rows])
        self.max_le = np.max([len(r) for r in self.rows_e])
        print(self.max_l)
        self.configs = traj.xyz

    def __len__(self):
        # Returns the length of the dataset
        return len(self.cv_labels)

    def __getitem__(self, idx):
        # Gets a configuration from the given index
        config = self.configs[idx]
        # Label is read from the numpy array
        label = torch.tensor(self.cv_labels[idx]).float()
        # if transformation functions are set they are applied to label and image
        config = torch.tensor(config).float()
        rows = self.rows[idx]
        cols = self.cols[idx]
        rows = nn.functional.pad(rows, [0, self.max_l - len(rows)], value=-1)
        cols = nn.functional.pad(cols, [0, self.max_l - len(cols)], value=-1)
        
        rows_e = self.rows_e[idx]
        cols_e = self.cols_e[idx]
        rows_e = nn.functional.pad(rows_e, [0, self.max_le - len(rows_e)], value=-1)
        cols_e = nn.functional.pad(cols_e, [0, self.max_le - len(cols_e)], value=-1)
        return config, label, rows, cols, rows_e, cols_e


def evaluate_model_gnn_mult_e(
    model: GNNCV, dataloader: DataLoader, n_mol: int, device: str, cols: list, n_at=1
) -> tuple:
    """Helper function that evaluates a model on a training set and calculates some properies for the generation of performance scatter plots.

    :param model: The model that is to be evaluated.
    :type model: GNNCV
    :param dataloader: Wrapper around the dataset that the model is supposed to be evaluated on.
    :type dataloader: torch.utils.data.Dataloader
    :param n_mol: Number of nodes in the graph of each frame. (Number of atoms or molecules)
    :type n_mol: int
    :param device: Device that the training is performed on. (Required for GPU compatibility)
    :type device: str
    :param cols: List of column indices representing the CVs the model is learning from the dataset.
    :type cols: list
    :param n_at: Number of atoms per molecule.
    :type n_at: int, optional
    :return: Returns the prediction of the model on each frame, the corresponding true values, the root mean square errors of the predictions and the r2 correlation coefficients.
    :rtype: List of List of float, List of List of float, List of float, List of float
    """
    preds = []
    ys = []
    for batch, (X, y, r, c, re, ce) in enumerate(dataloader):
        model.eval()
        # optimizer.zero_grad()
        batch_size = len(X)
        atom_positions = X.view(-1, 3 * n_at).to(device)
        row_new = []
        col_new = []
        for i in range(0, len(r)):
            row_new.append(r[i][r[i] >= 0] + n_mol * (i))
            col_new.append(c[i][c[i] >= 0] + n_mol * (i))

        row_new = torch.cat([ro for ro in row_new])
        col_new = torch.cat([co for co in col_new])

        if row_new[0] >= n_mol - 1:
            row_new -= n_mol
            col_new -= n_mol

        edges = [row_new.long().to(device), col_new.long().to(device)]
        pred = model(x=atom_positions, edges=edges, n_nodes=n_mol)

        [ys.append(ref.cpu().detach().numpy()) for ref in y[:, cols]]
        [preds.append(pre.cpu().detach().numpy()) for pre in pred]

    preds = np.array(preds)
    ys = np.array(ys)

    rmse_1 = np.mean((preds - ys) ** 2, axis=0) ** 0.5
    r2 = []
    for i in range(len(cols)):
        r2.append(np.corrcoef(preds[:,i], ys[:,i])[0, 1])

    return preds, ys, rmse_1, r2










device = "cuda" if torch.cuda.is_available() else "cpu"
print("Using {} device".format(device))

ds_ptm = GNNTrajectory_energy("../../train_round_4.dat","../../train_round_4.xyz", "../../ref_500.pdb",  1.8658222, 0.35,  0.49499999999999886, stride=1)
dataloader_ptm = DataLoader(ds_ptm, batch_size=64, shuffle=True)


ds_test = GNNTrajectory_energy("../../../round_4/test_2D_mtd.dat","../../../round_4/test_2D_mtd.xyz", "../../ref_500.pdb", 1.8658222,  0.35, 0.49499999999999886, stride=1)
dataloader_test = DataLoader(ds_test, batch_size=64, shuffle=True)

i=0
model = GNNCV_mult(2, hidden_nf=25, n_layers=1, pool_fn=torch.mean, act_fn=nn.Tanh())
model.to(device)
optimizer = optim.Adam(model.parameters(), lr=5e-4)
loss = nn.MSELoss()
conv = []
conv_mse = []
conv_pe = []
conv_test = []
conv_test_pe = []

scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=10, eta_min=1e-8)

for epoch in range(100):
    loss_tot, mse, pe = train_gnn_comm_reg(model, dataloader_ptm, 500, optimizer, loss, [0,1], device, 8.617333262e-5*1100, 1e-5, 1, 0.9, 1000000000, 5)
    conv.append(loss_tot)
    conv_mse.append(mse)
    conv_pe.append(pe)
    scheduler.step()

    if epoch % 5 == 0:
        test_mse, test_pe = test_gnn_e(model, dataloader_test, 500, loss, [0,1],device, 8.617333262e-5*1100, 1, 1, 0.9, 1000000000, 5)
        conv_test.append(test_mse)
        conv_test_pe.append(test_pe)


preds, labels, rmse, r2 = evaluate_model_gnn_mult_e(model, dataloader_ptm, 500, device, [0, 1])
preds_v, labels_v, rmse_v, r2_v = evaluate_model_gnn_mult_e(model, dataloader_test, 500, device, [0, 1])

ids = [0 ,1]
names = ["BCC", "FCC"]
for j in range(len(ids)):
    fig, (ax1, ax2) = plt.subplots(1, 2, sharey=False, figsize=(12,5))
    ax1.scatter(preds[:,j], labels[:,j], s=0.4, label="r = %.4f" % r2[j])
    ax1.legend()
    ax1.plot(labels[:,j], labels[:,j], color="black")
    ax1.set_title("Train " + names[ids[j]])
    ax1.set_xlabel("Prediction")
    ax1.set_ylabel("Label")
    ax2.scatter(preds_v[:,j], labels_v[:,j], s=0.4, label="r = %.4f | rmse=%.4f" % (r2_v[j],rmse_v[j]))
    ax2.legend()
    ax2.plot(labels_v[:,j], labels_v[:,j], color="black")
    ax2.set_title("Test " + names[ids[j]])
    ax2.set_xlabel("Prediction")
    ax2.set_ylabel("Label")
    plt.tight_layout()
    plt.savefig("Model_%d_PTM_%s.png" % (i, names[j]), dpi=750)
    plt.close()

np.savetxt("Model_pe_%d_conv.dat" % i, conv)
np.savetxt("Model_pe_%d_mse_conv.dat" % i, conv_mse)
np.savetxt("Model_pe_%d_pe_conv.dat" % i, conv_pe)
np.savetxt("Model_pe_%d_test_conv.dat" % i, conv_test)
np.savetxt("Model_pe_%d_test_pe_conv.dat" % i, conv_test_pe)
torch.save(model, "Model_pe_%d.pt" % i)

